<?php 
if(isset($_POST['checkbox'])== false)
{
if(array_key_exists('nome', $_POST)) {
    $nome = $_POST["nome"];
} else {
    $nome = "Nenhum nome inserido";
}
if(array_key_exists('convenio', $_POST)) {
    $convenio = $_POST["convenio"];
} else {
    $convenio = "Nenhum convênio inserido";
}
$tipo = $_POST["class"];
switch ($tipo) {
    case 'azul': 
		$cor='#0174DF';
		$tempo_espera = "até 240min";
		break; 
    case 'verde': 
		$cor='#04B404';
		$tempo_espera = "até 60min";
		break; 
    case 'amarelo': 
		$cor='#F7FE2E';
		$tempo_espera = "até 30min";
		break; 
	case 'vermelho': 
		$cor='#FE2E2E';
		$tempo_espera = "Tratamento imediato";
		break;
	case false: 
		$cor='white';
		$tempo_espera = "Não há definição";
		break;
}
}
else{
	echo "não mostrar nada";
}
//if(isset($_POST['meucheckbox'] && $cor == "red"))
//{
//    $estado="paciente sendo atendido";
//}
//else
//{
//    $estado="paciente espera";
//}

// $link = mysqli_connect("HOST", "USUARIO", "SENHA", "BASE");
 
// if (!$link) {
    // echo "Error: Falha ao conectar-se com o banco de dados MySQL." . PHP_EOL;
    // echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    // echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    // exit;
// }
 
// echo "Sucesso: Sucesso ao conectar-se com a base de dados MySQL." . PHP_EOL;
 
// mysqli_close($link); 
?>
<html>
<head>
<meta charset="utf-8">
<title>Lista de Pacientes</title>
<link rel="stylesheet" type="text/css" href="css/pa2.css"/>
<link rel="stylesheet" type="text/css" href="css/slider.css" />


<link rel="icon" type="imagem/jpg" href="img/download.jpg"/>

</head>
<body>
<div class="div">
	<!--<div class="div2"><img src="sc.jpg" style="height:100px;" id="img"></div>-->
	
	<div class="div3"><h1>Pronto Atendimento - Santana do Livramento</h1></div>
</div>
<div id="tabela">
<table dir="ltr" width="500px" border="2px" class="tg"
			summary="purpose/structure for speech output">
	<colgroup width="50%" />
	<colgroup id="colgroup" class="colgroup" align="center" 
			valign="middle" title="title" width="1*" 
			span="2" style="background:#ddd;" />
	<thead>
		<tr>
			<th scope="col">Nome</th>
			<th scope="col">Convênio</th>
			<th scope="col">Tempo de espera</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td style="background-color:<?php echo $cor;?>; text-align:center;"><?php echo $nome;?></td>
			<td style="background-color:<?php echo $cor;?>;text-align:center;"><?php echo $convenio;?></td>
			<td style="background-color:<?php echo $cor;?>;text-align:center;"><?php echo $tempo_espera;?></td>
		</tr>
	</tfoot>
</table>
</div>
<div id="cssSlider">
  <div id="sliderImages">
		<div><img id="si_1" src="img/h1.jpg" alt="" /></div>
		<div><img id="si_2" src="img/h2.jpg" alt="" /></div>
		<div><img id="si_3" src="img/h3.jpg" alt="" /></div>
		<div><img id="si_4" src="img/h4.jpg" alt="" /></div>
		<div><img id="si_4" src="img/h5.jpg" alt="" /></div>
		<div><div style="clear:left;"></div>
	</div>
</div>
<!--<div id="footer">
Desenvolvido por Vitor Vinicius
</div>-->
</body>
</html>
<script>
//function verificarCheckBox() {
//    var check = document.getElementsById("check"); 
//
//    for (var i=0;i<check.length;i++){ 
 //       if (check[i].checked == false){ 
   //         $estado1 = "Aguardando";
//
//        }  else {
//        $estado1 = "Em Atendimento";
//       }
//}
//}
</script>