<?php
$message = $data['msg'];
?>
<div id="page-wrapper" style="margin:150px;">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Cadastrar Novo Paciente</h1> <br>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">

                <div class="row">
                    <div class="col-lg-6">
                        <form role="form"  method="post">
                            <div class="form-group">
                                <label>Nome</label>
                                <input class="form-control" name="nome">
                            </div>
                            <div class="form-group">
                                <label>Convenio</label>
                                <input class="form-control" name="convenio">
                            </div>
                            <div class="form-group">
                                <label>Cor</label>
                                <input class="form-control" type="text" name="cor">
                            </div>
                            <div class="form-group">
                                <input name="add" type="submit" class="btn btn-primary" value="Registar">
                            </div>
                            <?php if ($message): ?>
                                <div class="form-group">
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo $message; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>