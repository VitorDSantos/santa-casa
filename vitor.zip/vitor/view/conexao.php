<?php

$con = mysqli_connect('localhost', 'root', '', 'pronto_atendimento');

if(!$con){
	die ("Não foi possível conectar");
}

?>