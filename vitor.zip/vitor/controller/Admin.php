<?php
class Admin extends Controller{
	function __construct(){
		parent::__construct();
			$this -> view('admin');
	}
	 public function index() {
        $this->view->load('index');
    }
}




























?>