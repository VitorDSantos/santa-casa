﻿<?php
class AdminPaciente extends Admin{
	public function __construct() {
        parent::__construct();
        $this->model = new pacienteDao();
    }
	public function index(){
		$data['listaPaciente'] = $this->model->getListaPaciente();
        $this->view->load("paciente", $data);
	}
	 public function addPaciente() {
        $data['msg']="";
        if (filter_input(INPUT_POST, 'add')) {
            $nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
            $convenio = filter_input(INPUT_POST, 'convenio',FILTER_SANITIZE_STRING);
            $cor = filter_input(INPUT_POST, 'cor',FILTER_SANITIZE_STRING);
			
            if($nome && $convenio && $cor) {
                if($this->model->inserirPaciente(new Paciente($nome, $convenio, $cor,null))){
                    $this->view->location('AdminPaciente');
                }else{
                    $data['msg']= "Error al Registar!!";
                }
            }else{
                $data['msg']= "Rellene todos los Campos!";
            }
        }
        $this->view->load('add_paciente',$data);
    }
	
	public function editarPaciente($id) {
        $data['users']=$this->model->getPacienteById($id);
		$data['msg']="";
        if (filter_input(INPUT_POST, 'edit')) {
			$id = filter_input(INPUT_POST, 'id',FILTER_SANITIZE_STRING);
            $nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
            $convenio = filter_input(INPUT_POST, 'convenio',FILTER_SANITIZE_STRING);
            $cor = filter_input(INPUT_POST, 'cor',FILTER_SANITIZE_STRING);
            if($id && $nome && $login && $pass && $email) {
                $a=new Usuario($id, $nome, $login, $pass, $email);                
                if($this->model->atualizarUsuario($a)){
					$this->index();
					return true;
                }else{
                    $data['msg']= "Error ao Atualizar!!";
                }
            }else{
                $data['msg']= "Preencha todos os campos!";
            }
        }else if(filter_input(INPUT_POST, 'exit'))
		{
			$this->view->location($this->view->getUrl()."/AdminPaciente");
			return true;
		}
        $this->view->load('header');
        $this->view->load('edit_paciente',$data);
        $this->view->load('footer');
    }
	
	public function deletarPaciente($id) {
        $data['msg'] = '';
        $data['paciente'] = $this->model->getPacienteById($id);
        $this->view->load('delete_paciente', $data);
    }
    
    
    public function removerPaciente() {
        $data['msg'] = '';
        if (filter_input(INPUT_POST, 'delete')) {
            $id = filter_input(INPUT_POST,'id',FILTER_SANITIZE_STRING);
            if($this->model->removerPaciente($id)){
                $data['msg'] ='paciente excluída com sucesso!';
            }else{
                $data['msg'] ='Erro ao excluir Usuario!';            
            }           
        } elseif (filter_input(INPUT_POST, 'exit')) {
            $this->view->location('AdminPaciente/');
        }
        
    }
}
?>