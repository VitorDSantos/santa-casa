﻿<?php
$pastaInterna = "";
define('DIRPAGE',"http://{$_SERVER['HTTP_HOST']}/{$pastaInterna}");
if(substr($_SERVER['DOCUMENT_ROOT'],-1)=='/'){
define('DIRREQ',"{$_SERVER['DOCUMENT_ROOT']}{$pastaInterna}");
}else{
	define('DIRREQ',"{$_SERVER['DOCUMENT_ROOT']}/{$pastaInterna}");

}
//dynamic base_name
// $path = dirname($_SERVER['PHP_SELF']);
// $position = strrpos($path,'/') + 1;
// $localDir = substr($path,$position);

//Simple MVC Configuration File
//Inicialização da variável $config
// unset($config);
// $config = new stdClass();
// $config->defaultClass = "Home";
// $config->base_url = '/vitor/';
// $config->url = 'http://'.$_SERVER['HTTP_HOST']. $config->base_url;
// $config->asset = $config->base_url . '';
// $config->template = 'default';
//FTP: senha nome
//Database
// if ($_SERVER['HTTP_HOST'] === "localhost:8080" || $_SERVER['HTTP_HOST'] == '127.0.0.1')
// {
    // $config->dbuser = 'santacasalivra02';
    // $config->dbpassword = 's4ud32019';
    // $config->dbname = 'pronto_atendimento';
    // $config->dbhost = 'localhost';
    // $config->dbdrive = 'mysql';
// } else {
    // $config->dbuser = 'pronto_atendimento';
    // $config->dbpassword = 's4ud32019';
    // $config->dbname = 'pronto_atendimento';
    // $config->dbhost = '127.0.0.1';
    // $config->dbdrive = 'mysql';
// }
?>