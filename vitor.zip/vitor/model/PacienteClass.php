<?php
class Paciente{
	private $id;
	private $nome;
	private $convenio;
	private $cor;
}
public function __construct($id=null,$nome,$convenio,$cor){
	$this ->id = $id;
	$this ->nome = $nome;
	$this ->convenio = $convenio;
	$this ->cor = $cor;
}
function getId(){
	return $this->id;
}

function getNome(){
	return $this->nome;
}

function getConvenio(){
	return $this->convenio;
}

function getCor(){
	return $this->convenio;
}
function setId($id){
	$this->id = $id;
}

function setNome($nome){
	$this->nome = $nome;
}

function setConvenio($convenio){
	$this->convenio = $convenio;
}

function setCor($cor){
	$this->cor = $cor;
}

?>