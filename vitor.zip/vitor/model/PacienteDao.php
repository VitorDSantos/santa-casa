<?php
class pacienteDao extends Model{
	 public function __construct() {
        parent::__construct();
        $this->listaPaciente = [];
} 
public function getListaPaciente() {
    $sql = "SELECT * FROM paciente";
    $result = $this->ExecuteQuery($sql, []);
    foreach ($result as $linha) {
        $paciente = new paciente($linha['id'], $linha['nome'], 
		$linha['convenio'], $linha['cor']);
        $this->listaPaciente[] = $paciente;
    }
	return $this->listaPaciente;
}
 public function getPacienteById($id) {
    $sql = "SELECT * FROM paciente WHERE id = :id";
    $result = $this->ExecuteQuery($sql, [':id' => $id]);         
        if ($result) {
            $users = $result[0];
            return new Paciente($users['id'], $users['nome'], 
			$users['convenio'], $users['cor']);
        } else {
            return null;
        }
}
public function inserirPaciente($users) {
        $sql = "INSERT INTO paciente(nome,convenio,cor) 
		VALUES(:nome,:convenio,:cor)";
        $result = $this->ExecuteCommand($sql, 
                [':nome' => $users->getNome(),
				':convenio' => $users->getConvenio(),
				':cor' => $users->getCor(),
				]);
        if ($result) {
            return true;
        } else {
            return false;
        }
}
public function editarPaciente($users){
		$sql = "UPDATE paciente SET nome = :nome, convenio = :convenio,
		cor = :cor WHERE id = :id";
        $result = [':nome' => $users->getNome(),
				':convenio' => $users->getConvenio(),
				':cor' => $users->getCor(),
                ':id' => $users->getId()];
        if ($this->ExecuteCommand($sql, $result)) {
            return true;
        } else {
            return false;echo "errou parceiro";
        }
}
public function removerPaciente($id) {
        $sql2 = "DELETE FROM paciente WHERE id = :id";
        if($this->ExecuteCommand($sql2, [':id'=>$id])){
            return true;
        }else{
            return false;
        }
        
    }
}













?>