<?php
$vids = null;
$message = "Video não encontrada !!";
if ($data) {
    $message = $data['msg'];
    if (isset($data['vids'])) {
        $vids = $data['vids'];
    }
}
?>
<div id="page-wrapper" style="margin:150px;">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> Deletar Video</h1> <br>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">

                <div class="row">
                    <div>
                        Quer excluir o arquivo??
                        <form role="form" method="post" action='<?php echo $this->url?>AdminVideos/removeVideos/'>
                            <?php if($vids):?>
							<input type="hidden" value="<?php echo $vids->getIdvideos(); ?>" name="id">
                            <?php endif;?>
                            <div class="form-group">
                                <?php if($vids):?>
                                <input name="delete" type="submit" class="btn btn-primary" value="eliminar">
                                  <?php endif;?>
								<input name="exit" type="submit" class="btn btn-danger" value="Cancelar/Volver">
                            </div>
                            <?php if ($message): ?>
                                <div class="form-group">
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo $message; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->