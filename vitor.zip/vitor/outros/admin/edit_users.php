<?php
$message = $data['msg'];
$list_users = $data['users'];
?>
<div id="page-wrapper" style="margin:150px;">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit Usuario</h1> <br>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">

                <div class="row">
                    <div>
                        <form role="form" method="post">
                            <div class="form-group">
                                <label>Nome</label>
                                <input class="form-control" name="nome" value="<?php echo $list_users->getNome(); ?>">
                            </div>
                            <div class="form-group">
                                <label>Login</label>
                                <input class="form-control" name="login" value="<?php echo $list_users->getLogin(); ?>">
                            </div>
                            <div class="form-group">
                                <label>Senha</label>
                                <input class="form-control" name="pass" value="<?php echo $list_users->getSenha(); ?>">
                            </div>
							<div class="form-group">
                                <label>Email</label>
                                <input class="form-control" name="email" value="<?php echo $list_users->getEmail(); ?>">
                            </div>
							<input type="hidden" value="<?php echo $list_users->getIdUser(); ?>" name="id">
                            <div class="form-group">
                                <input name="edit" type="submit" class="btn btn-primary" value="Registar">
								<input name="exit" type="submit" class="btn btn-danger" value="Cancelar">
                            </div>
                            <?php if ($message): ?>
                                <div class="form-group">
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo $message; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->