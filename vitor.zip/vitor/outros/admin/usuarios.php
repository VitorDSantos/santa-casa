<?php
if($data){
    $list_users = $data['listUsuarios'];
	//echo var_dump($list_vids);
}else{
    $list_users = null;
}
?><div style="margin-top:100px;">
        <div class="col-lg-12">
            <div class="panel panel-default">
				<a href="<?php echo $this->url?>AdminUsuarios/addUsuarios" style="float:right;">
					<div class="table-data__tool-right">
						<button class="au-btn au-btn-icon au-btn--green au-btn--small">
							<i class="zmdi zmdi-plus"></i>Agregar
						</button>
						<div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
							<div class="dropDownSelect2"></div>
						</div>
                </div>
				</a>
                <div class="panel-heading">
                    Usuarios Cadastrados
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Login</th>
                                <th>Nome</th>                               
                                <th>Senha</th>                               
                                <th>Email</th>                               
                                <th colspan="0.5">Ações</th>                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count = 0;?>
                         <?php if($list_users):?>   
                           <?php foreach($list_users as $users): ?> 
                            <?php $count++; $ccs_class=($count%2==0)?'even':'odd';?>
                                <tr class="<?php echo $ccs_class;?>">
                                    <td><?php echo $users->getIdUser();?></td>
                                    <td><?php echo $users->getLogin();?></td>
                                    <td><?php echo $users->getNome();?></td>
                                    <td><?php echo $users->getSenha();?></td>
                                    <td><?php echo $users->getEmail();?></td>
                                    <td>
										<div class="table-data-feature">
											<a href="<?php echo $this->url?>AdminUsuarios/editUsuarios/<?php echo $users->getIdUser();?>">
												<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
													<i class="zmdi zmdi-edit"></i>
												</button>
											</a>
											<a href="<?php echo $this->url?>AdminUsuarios/deleteUsuarios/<?php echo $users->getIdUser();?>">
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                    <i class="zmdi zmdi-delete"></i>
                                                </button>
											</a>
                                        </div>
									</td>
                                </tr>                            
                            
                            <?php endforeach;?>
                          <?php endif;?>   
                        </tbody>
                    </table>
                     
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>

<!-- /.row -->

</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
</body></html>