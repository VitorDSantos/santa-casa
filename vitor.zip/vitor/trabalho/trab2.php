<?php
	include_once 'trab1.php';
	
	$contatos = new classContatos();
	$insert = $contatos->contato();
	class classContatos{
		public function contato(){
				$nome = $_POST['nome'];
				$telefone = $_POST['telefone'];
				$email = $_POST['email'];
		}
	}
?>