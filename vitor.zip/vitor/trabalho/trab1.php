<?php
class Contatos{
		public $nome;
		public $telefone;
		public $email;

	public function __construct(){
		
	}
	function getNome() {
        return $this->nome;
    }
	function setNome($nome) {
        $this->nome = $nome;
    }
	function getTelefone(){
		return $this->telefone;
	}
	function setTelefone($telefone){
		$this-> telefone = $telefone;
	}
	function getEmail(){
		return $this->email;
	}
	function setEmail($email){
		$this -> email =$email;
	}
}
?>