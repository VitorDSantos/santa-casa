<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="Post" action="conectar.php">
            informe o nome:<input type="text" name="nome"><br>
            informe o telefone:<input type="number" name="telefone"><br>
            <input type="submit" value="salvar">
        </form>
    </body>
</html>
