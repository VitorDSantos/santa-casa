<?php
	include_once 'trab1.php';
	include_once 'conexaoSimples.php';
	
				$nome = $_POST['nome'];
				$telefone = $_POST['telefone'];
				$email = $_POST['email'];
				
				$z = new Contatos();
				
				$z->setNome($nome);
				$z->setTelefone($telefone);
				$z->setEmail($email);
				
				
				$a = $z->getNome($nome);
				$b = $z->getTelefone($telefone);
				$c = $z->getEmail($email);
				
				$array = array("nome".$a,
							   "telefone".$b,
							   "email".$c);
				
				$conexao = new conect();
				$conexao-> conectar($array);
				
	
?>