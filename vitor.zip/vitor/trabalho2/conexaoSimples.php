<?php
	include_once 'trab1.php';
	include_once 'trab2.php';
	class conect{
		public function conectar($array){
			
			
		$q = json_encode($array);
		$q2  = urlencode($q);
		
		$conect = "http://168.197.255.216:8081/WS/webresources/lpw2/escolha/".$q2;
		
		$client = curl_init($conect);
		
		curl_setopt($client, CURLOPT_RETURNTRANSFER, 1);

		$response = curl_exec($client);

		$aa = json_decode($response);
		
		echo $aa->resposta;
		}
	}

	?>